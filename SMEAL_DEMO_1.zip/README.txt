first of all, THIS IS NOT MEANT FOR EDUCATION AND LEARNING!!!!!

second of all, you can put the folder into C:\Users\<YOURNAMEHERE>\AppData\Roaming\PizzaTower_GM2\towers\Tomato_Monsters_Education_And_Learning

replace <YOURNAMEHERE> with your windows user name

and with that thats all!

enjoy!!!